
# declare -a ALLDEFS=("-D__583")
# declare -a ALLDEFS=("")

declare -a ALLDEFS=("")
declare -a ALLOPTS=("-g -O0 -fno-omit-frame-pointer"  "-Ofast -march=native -DNDEBUG")

